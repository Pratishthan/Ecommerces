const pool = require("../dbconfig")

const queries = require("../queries.js");



const getOrders = (req,res) => {
    pool.query(queries.getOrders, (error, results) => {
        if (error) throw error ;
        res.status(200).json(results.rows);
    })
 }


 const getordersById = (req,res) =>{
    const ord_id = parseInt(req.params.order_id);
    pool.query(queries.getorderById,[ord_id], (error, results) => {
     if (error) throw error ;
     res.status(200).json(results.rows);
    })
 }

 const createorder = (req,res) => {
    const{token, order_address, product_id, quantity, item_price, shipping_price, total_price, payment_method} = req.body;
    // pool.query(queries.checkproductnameexits, [product_name], (error, results) => {
    //     if (results.rows.length){
    //         res.send("Product name already exists")
    //     }

        pool.query(queries.createorder, [token, order_address, product_id, quantity, item_price, shipping_price, total_price, payment_method], (error,results) => {
            if (error) throw error;
            res.status(201).send("Order created successfully")
        })




}


const deleteproductId=(req,res)=>{

    const ord_id=parseInt(req.params.order_id);;
    
    pool.query(query.deleteorderbyId,[ord_id],(error,results)=>{
    if(error){
        res.send("order Does not exist")
    }
    else{
        pool.query(query.orderbyId,[ord_id],(error,results)=>{
            if(error) throw error;
            res.send("order deleted  successfully")
        })
    }
    });
    
    }
    const updateorder=(req,res)=>{

        const ord_id=parseInt(req.params.order_id);
        const{token, order_address, product_id, quantity, item_price, shipping_price, total_price, payment_method} = req.body;
        pool.query(query.getorerbyId,[ord_id],(error,results)=>{
        if(!results.rows.length){
            res.send("Order Does not exist")
        }
        else{
            pool.query(query.updateproduct,[order_address, product_id, quantity, item_price, shipping_price, total_price, payment_method],(error,results)=>{
                if(error) throw error;
                res.send("Order Updated  successfully")
            })
        }
        });
        
        }


 module.exports ={
    getOrders,
    getordersById,
    createorder,
    deleteproductId,
    updateorder
 
}

