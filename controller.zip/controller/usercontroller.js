const pool = require("../dbconfig")


const getUsers = (req,res) => {
   pool.query(user.getUsers, (error, results) => {
       if (error) throw error ;
       res.status(200).json(results.rows);
   })
}

module.exports ={
    getUsers
}














module.exports.SignUp = async (req,res) => {

    const{name, email, phone, work, Role, password, cpassword} = req.body;

    if ( ! name ||! email || !phone ||! work || ! Role || !password || !cpassword){
        return res.status(422).json({
            "Error" : "Please fill data properly"
        });
    }
    try{
        
        // const userExist  = await User
        //    .findOne({email:email});
        //     if(userExist){
        //      return res.status(409).json({
        //         "Error" : "Email already exists"
        //     });
            // }
             if(password != cpassword){
                return res.status(422).json({
                    "message" : "Password not matching"
                });
            }else{
                const user = new User({name, email, phone, work, password, cpassword});
            

                 await user.save();
               
                res.status(201).json({
                    "message" : "user registered successfully"
                });
            }
            

          
                
               
  
            
        }
    catch(err){
        console.log(err);
        res.status(400).send(error);

    }


   
}; 

module.exports.login = async (req,res) => {
    try{
        const{ email, password} =req.body;

        if (! email ||  !password ){
            return res.status(401).json({
                "Error" : "Please fill all the details"
            });
        }

        const userLogin  = await User.findOne({email:email});
        //console.log(userLogin);
        if(userLogin){
            const isMatch = await bcrypt.hash(password, userLogin.password);

            const token = await userLogin.generateAuthToken();
            console.log("token aa gya" + token);

            res.cookie("nttmuks", token,{
                expires : new Date(Date.now() + 25892000000),
                httpOnly: true
             });

            if ( !isMatch){
                 res.status(409).json({
                    "Error" : "Invalid Credentials"
                });
            }else{
                res.status(201).json({
                    "message" : "user login successfully"
                });
            }

        }else{
            res.status(409).json({
                "Error" : "Invalid cred"
            });
        }

    } catch(err){
        console.log(err);

    }
          
 };  
