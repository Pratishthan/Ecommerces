const pool = require("../dbconfig");
const query=require('../queries.js');


const getreviwes = (req,res) =>{
    const id = parseInt(req.params.product_id);
    pool.query(queries.getreviews,[id], (error, results) => {
     if (error) throw error ;
     res.status(200).json(results.rows);
    })
 }

 const addreview = (req,res) => {
    const{product_name, product_price,product_details} = req.body;
    pool.query(queries.checkproductnameexits, [product_name], (error, results) => {
        if (results.rows.length){
            res.send("Product name already exists")
        }

        pool.query(queries.addProduct, [product_name, product_price,product_details], (error,results) => {
            if (error) throw error;
            res.status(201).send("Products added successfully")
        })
    })



}
 
module.exports ={
    getreviwes
 
}