const pool = require("../dbconfig")

const queries = require("../queries.js");


const getProducts = (req,res) => {
   pool.query(queries.getProducts, (error, results) => {
       if (error) throw error ;
       res.status(200).json(results.rows);
   })
}

const getProductsById = (req,res) =>{
   const id = parseInt(req.params.product_id);
   pool.query(queries.getProductsById,[id], (error, results) => {
    if (error) throw error ;
    res.status(200).json(results.rows);
   })
}

const  getproductbyname=(req,res)=>{
    const pro_name=req.params.product_name;
    query.getproductbyname += "'"+pro_name+"'"+";";
    console.log(query.getproductbyname);
    pool.query(query.getproductbyname,(error,results)=>{
        if(error){
            res.send("product Does not exist")
        }
        else{
             console.log(results);
             res.send(results);
            }
    // if(error) throw error

    })
}

const addProduct = (req,res) => {
    const{product_name, product_price,product_details} = req.body;
    pool.query(queries.checkproductnameexits, [product_name], (error, results) => {
        if (results.rows.length){
            res.send("Product name already exists")
        }

        pool.query(queries.addProduct, [product_name, product_price,product_details], (error,results) => {
            if (error) throw error;
            res.status(201).send("Products added successfully")
        })
    })



}

const deleteproductId=(req,res)=>{

    const pro_id=parseInt(req.params.product_id);;
    
    pool.query(query.getproductbyId,[pro_id],(error,results)=>{
    if(error){
        //res.send("Category Does not exist")
    }
    else{
        pool.query(query.productbyId,[pro_id],(error,results)=>{
            if(error) throw error;
            res.send("product deleted  successfully")
        })
    }
    });
    
    }

    
    const updateproduct=(req,res)=>{

        const pro_id=parseInt(req.params.product_id);
        const{product_name, product_price,product_details} = req.body;
        pool.query(query.getproductbyId,[pro_id],(error,results)=>{
        if(!results.rows.length){
            res.send("Product Does not exist")
        }
        else{
            pool.query(query.updateproduct,[product_name, product_price,product_details,pro_id],(error,results)=>{
                if(error) throw error;
                res.send("Product Updated  successfully")
            })
        }
        });
        
        }

module.exports ={
    getProducts,
    getProductsById,
    addProduct,
    deleteproductId,
    getproductbyname,
    updateproduct
 
}